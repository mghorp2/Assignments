library(ISLR)
library(class)
library(MASS)
Weekly<-data.frame(Weekly)
head(Weekly)
str(Weekly)
summary(Weekly)
dim(Weekly)
cor(Weekly[,-9])
plot(Weekly[,-9])

# linear regression

glm.fits<- glm(formula= Direction ~ Lag1+Lag2+Lag3+Lag4+Lag5+Volume,family = binomial, data = Weekly)
summary(glm.fits)

glm_prob<-predict(glm.fits,type="response")
contrasts(Weekly$Direction)
glm.pred=rep("Down",1089)
glm.pred[glm_prob>0.5]="Up"
table(glm.pred,Weekly$Direction)
mean(glm.pred==Weekly$Direction)

# Part d
Week_train<-subset(Weekly,Year<2009)
Week_tst<-subset(Weekly,Year>2008)

glm.train<- glm(formula= Direction ~ Lag2,family = binomial, data = Week_train)
summary(glm.train)
glm.tst<-predict(glm.train,newdata=Week_tst,type="response")

glm_tst=rep("Down",104)
glm_tst[glm.tst>0.5]="Up"
table(glm_tst,Week_tst$Direction)
mean(glm_tst==Week_tst$Direction)

#lda

lda_trn<-lda(Direction ~ Lag2, data = Week_train)
lda_trn
plot(lda_trn)

lda_tst<-predict(lda_trn,Week_tst)
table(lda_tst$class,Week_tst$Direction)
mean(lda_tst$class==Week_tst$Direction)

#qda

qda_trn<- qda(Direction ~ Lag2, data = Week_train)
qda_trn
qda_tst<-predict(qda_trn,Week_tst)
table(qda_tst$class,Week_tst$Direction)
mean(qda_tst$class==Week_tst$Direction)

#knn
set.seed(12)
train.X=cbind(Week_train$Lag2)
test.X=cbind(Week_tst$Lag2)
knn_trn = knn(train = train.X,test = test.X, cl=as.factor(Week_train$Direction),k=1)
table(knn_trn,Week_tst$Direction)
mean(knn_trn==Week_tst$Direction)

# trying different variables and models on test data

# logistic regression with Lag1 and lag2 variables
glm.train_1<- glm(formula= Direction ~ Lag1+I(Lag2^2),family = binomial, data = Week_train)
summary(glm.train_1)
glm.tst_1<-predict(glm.train_1,newdata=Week_tst,type="response")
glm_tst_1=rep("Down",104)
glm_tst_1[glm.tst_1>0.5]="Up"
table(glm_tst_1,Week_tst$Direction)
mean(glm_tst_1==Week_tst$Direction)

# logistic regression with Lag2 and lag5 variables
glm.train_2<- glm(formula= Direction ~ Lag2+Lag5,family = binomial, data = Week_train)
summary(glm.train_2)
glm.tst_2<-predict(glm.train_2,newdata=Week_tst,type="response")
glm_tst_2=rep("Down",104)
glm_tst_2[glm.tst_2>0.5]="Up"
table(glm_tst_2,Week_tst$Direction)
mean(glm_tst_2==Week_tst$Direction)

# logistic regression with Lag1, Lag2, Lag3 and Lag4 variables

glm.train_3<- glm(formula= Direction ~ Lag2+Lag1+Lag3:Lag4,family = binomial, data = Week_train)
summary(glm.train_3)
glm.tst_3<-predict(glm.train_3,newdata=Week_tst,type="response")
glm_tst_3=rep("Down",104)
glm_tst_3[glm.tst_3>0.5]="Up"
table(glm_tst_3,Week_tst$Direction)
mean(glm_tst_3==Week_tst$Direction)

# lda 

lda_trn_1<-lda(Direction ~ Lag2+Lag2*Lag5, data = Week_train)
lda_trn_1
lda_tst_1<-predict(lda_trn_1,Week_tst)
table(lda_tst_1$class,Week_tst$Direction)
mean(lda_tst_1$class==Week_tst$Direction)

lda_trn_2<-lda(Direction ~ Lag1+Lag2+Lag3+Volume, data = Week_train)
lda_tst_2<-predict(lda_trn_2,Week_tst)
table(lda_tst_2$class,Week_tst$Direction)
mean(lda_tst_2$class==Week_tst$Direction)

lda_trn_3<-lda(Direction ~ Lag2+I(Volume^3), data = Week_train)
lda_tst_3<-predict(lda_trn_3,Week_tst)
table(lda_tst_3$class,Week_tst$Direction)
mean(lda_tst_3$class==Week_tst$Direction)

#qda

qda_trn_1<- qda(Direction ~ Lag2+Lag1+poly(Volume,3), data = Week_train)
qda_tst_1<-predict(qda_trn_1,Week_tst)
table(qda_tst_1$class,Week_tst$Direction)
mean(qda_tst_1$class==Week_tst$Direction)

qda_trn_2<- qda(Direction ~ I(Lag2^2)+Lag1+Lag3+Lag4:Lag5, data = Week_train)
qda_tst_2<-predict(qda_trn_2,Week_tst)
table(qda_tst_2$class,Week_tst$Direction)
mean(qda_tst_2$class==Week_tst$Direction)

qda_trn_3<- qda(Direction ~ Lag2+Lag5, data = Week_train)
qda_tst_3<-predict(qda_trn_3,Week_tst)
table(qda_tst_3$class,Week_tst$Direction)
mean(qda_tst_3$class==Week_tst$Direction)


#knn

set.seed(12)

train.X1=cbind(Week_train$Lag2,Week_train$Lag3,Week_train$Lag4)
test.X1=cbind(Week_tst$Lag2,Week_tst$Lag3,Week_tst$Lag4)
knn_trn1 = knn(train = train.X1,test = test.X1, cl=as.factor(Week_train$Direction),k=3)
table(knn_trn1,Week_tst$Direction)
mean(knn_trn1==Week_tst$Direction)

train.X2=cbind(Week_train$Lag2,Week_train$Lag4,Week_train$Volume)
test.X2=cbind(Week_tst$Lag2,Week_tst$Lag4,Week_tst$Volume)
knn_trn2 = knn(train = train.X2,test = test.X2, cl=as.factor(Week_train$Direction),k=5)
table(knn_trn2,Week_tst$Direction)
mean(knn_trn2==Week_tst$Direction)

train.X3=cbind(Week_train$Lag2,Week_train$Lag5)
test.X3=cbind(Week_tst$Lag2,Week_tst$Lag5)
knn_trn3 = knn(train = train.X3,test = test.X3, cl=as.factor(Week_train$Direction),k=4)
table(knn_trn3,Week_tst$Direction)
mean(knn_trn3==Week_tst$Direction)

